import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import EducationalComponent from './components/EducationalComponent';

function App() {
  return (
    <div className="App">
     <EducationalComponent />
    </div>
  );
}

export default App;
