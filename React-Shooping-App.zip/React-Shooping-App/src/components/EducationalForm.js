import React, { useEffect, useState } from 'react'
import { Button, Modal } from 'react-bootstrap'

function EducationalForm(props) {
    const [educationFormData, seteducationFormData] = useState({
        course:'',
        institution: 'TY',
        yop:2020,
        percentage: 10
    })
    const handleClose = () =>{
        props.updateShowModal('', false)
    }
    const saveData = () =>{
        props.getEducationData(educationFormData)
       
    }
    useEffect(() => {
        seteducationFormData({...props.editableEducation})
    }, [props.editableEducation])
    
    return (
        <div>
           <Modal show={props.showModal} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Educational Form</Modal.Title>
        </Modal.Header>
        <Modal.Body> 
            <input name="course" 
            value={educationFormData.course}
            onChange={(e)=>{
                seteducationFormData({
                    ...educationFormData,
                    course: e.target.value
                })
            }} />
            </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={saveData}>
            {props.modalType === 'add' ? 'ADD' : 'EDIT'}
          </Button>
        </Modal.Footer>
      </Modal>
           
        </div>
    )
}

export default EducationalForm
