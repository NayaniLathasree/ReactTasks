import React from "react";
import { Button, Table } from "react-bootstrap";

function EducationalTable({getEditableEducation,updateShowModal, educationalData }) {

    const sendEducationData = (education,index) =>{
        getEditableEducation(education,index)
    }
   return (
    <div>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>#</th>
            <th>Course</th>
            <th>Institution</th>
            <th>Year of Passing</th>
            <th>Percentage</th>
            <th><Button variant="outline-primary" onClick={()=>{updateShowModal('add', true)}}>Add</Button></th>
          </tr>
        </thead>
        <tbody>
          {educationalData.map((education, index) => {
            return (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{education.course}</td>
                <td>{education.institution}</td>
                <td>{education.yop}</td>
                <td>{education.percentage}</td>
                <td>
                <Button style={{marginRight: '10px'}} 
                variant="outline-success" onClick={()=>{
                    sendEducationData(education,index)
                }}>
                    Edit
                    </Button>
                <Button variant="outline-danger">Delete</Button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
}

export default EducationalTable;
