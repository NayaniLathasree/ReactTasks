import React from 'react';
import Post from '../components/Post/Post';

const PostPage = () => {
    return (
        <div>
            <Post/>
        </div>
    )
}

export default PostPage
