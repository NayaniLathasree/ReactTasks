import React from 'react';
import ResetPassword from '../components/ResetPassword/ResetPassword';

const ResetPasswordPage = () => {
    return (
        <div>
            <ResetPassword/> 
        </div>
    )
}

export default ResetPasswordPage;
