import React, { useState } from 'react';
import './App.css';
import KeyDownFunctional from './KeyDownFunctional';
import KeyDownClass from './KeyDownClass';

function App() {
  const [toggle, setToggle] = useState(true);
  
  return <>
    <h1>React keydown useEffect componentDidMount <span role="img" aria-label="keyboardemoji">⌨️</span></h1>
    <div className="choiceRadio">
      <input type="radio" name="choice" value="class" checked={toggle} onChange={() => setToggle(true)} />
      <label htmlFor="class">Class Component</label>

      <input type="radio" name="choice" value="class" checked={!toggle} onChange={() => setToggle(false)} />
      <label htmlFor="class">Functional Component</label>
    </div>

    {toggle ? <KeyDownClass /> : <KeyDownFunctional />}
  </>
}

export default App;