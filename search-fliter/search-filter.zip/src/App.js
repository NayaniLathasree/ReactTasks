import  SearchTable from './components/SearchTable'

function App() {
  return (
    <div className="App">

      < SearchTable />
    </div>
  );
}

export default App;
